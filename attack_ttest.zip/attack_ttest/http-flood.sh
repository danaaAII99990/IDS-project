#!/bin/bash

TARGET_IP="192.168.1.187"
TARGET_PORT=80

TARGET_URL="http://${TARGET_IP}:${TARGET_PORT}"

for ((i=0; i<100; i++)); do
  # Send HTTP requests in a loop
  curl -s -o /dev/null -w "%{http_code}" $TARGET_URL &
done

# Wait for all background processes to finish
wait

