#!/bin/bash

# Function to extract the attacker's IP address from a Snort alert
function extract_attacker_ip() {
  # Implement your logic to extract the IP address from the Snort alert
  # based on your specific Snort configuration and alert format.
  # Example using grep and awk (adjust as needed):
  grep "Repeating 'A' pattern detected" /home/test/Desktop/alert.log | awk '{print $13}' | cut -d: -f1 | head -n1
}

# Continuously monitor Snort alerts
while true; do
  attacker_ip=$(extract_attacker_ip)

  if [ -n "$attacker_ip" ]; then
    # Block the attacker's IP address using ufw
    ufw deny from "$attacker_ip" to any comment "Blocked by Snort alert"

    # Log the action
    echo "$(date) - Blocked attacker IP: $attacker_ip" >> snort_blocks.log
  else
    # Log if no attacker IP is found in the alert
    echo "$(date) - No attacker IP found in the alert" >> snort_blocks.log
  fi

  # Sleep for a short interval before checking again
  sleep 5
done

