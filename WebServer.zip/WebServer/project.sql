-- Create Database
CREATE DATABASE IF NOT EXISTS project;

-- Switch to the Database
USE project;

-- Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Optionally, you can add indexes or constraints based on your requirements
-- For example, adding a unique constraint on the email field
-- ALTER TABLE users ADD UNIQUE (email);

