<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "new_password"; // Replace with your MySQL password
$database = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connection successful!<br>";

    // Example data for the user
    $name = "leen";
    $email = "leen@example.com";
    $password = "1234"; // Replace with the actual password

    // Hash the password using bcrypt (for security)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert data into the 'users' table
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "Record inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>

